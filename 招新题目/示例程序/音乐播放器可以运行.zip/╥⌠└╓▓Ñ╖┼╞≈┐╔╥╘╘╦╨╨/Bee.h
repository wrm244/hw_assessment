#ifndef __Bee_H__
#define __Bee_H__


void Bee_Set(unsigned char Mode,Count);

#endif

#include <REGX52.H>
#include "Delay.h"
#include "Bee.h"
#include "Timer1.h"

void main()
{
	Timer1_Init();
	Bee_Set(0,0);	
}
